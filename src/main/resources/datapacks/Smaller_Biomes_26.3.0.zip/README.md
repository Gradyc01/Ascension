# 🗺️ Smaller Biomes

**Smaller Biomes** is a datapack that slightly reduces the size of biomes, keeping the satisfaction of exploring the map without spoiling it.

Ideal for game modes such as bingos.

## Example on one same seed (size: 1024/-1024)
### Without Smaller Biomes
![Without Smaller Biomes](https://cdn.modrinth.com/data/cached_images/e8338db4ce472482adc548b7fedfe401cd8638de_0.webp)
### With Smaller Biomes
![With Smaller Biomes](https://cdn.modrinth.com/data/cached_images/bba7f784574926ea61b8e2658eeec31bcc6528cd_0.webp)
