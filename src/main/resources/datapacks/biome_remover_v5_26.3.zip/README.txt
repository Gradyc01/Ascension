Biome Remover v5 for Minecraft Java 26.3

INSTALL: add this zip on the Data Packs screen when creating a NEW world, before clicking Create.
Works for the default world type only (not Large Biomes / Amplified / Superflat).

OCEANS: about 10% of vanilla ocean area remains (continentalness remap in
data/minecraft/worldgen/density_function/overworld/continents.json; raw_continents.json uses minecraft:continentalness).
Tuning: change the 0.73 in continents.json (larger = fewer oceans).

GENERAL BIOMES: plains, snowy_plains, desert, savanna, sunflower_plains together about 40% of the map.
The freed land is shared among all other remaining biomes, including the reduced ones, for more frequent biome changes.

REMOVED: forest, birch_forest, windswept_forest, frozen_peaks, jagged_peaks, meadow, snowy_slopes, stony_peaks,
windswept_gravelly_hills, windswept_hills, savanna_plateau, windswept_savanna, old_growth_spruce_taiga, old_growth_pine_taiga.

REDUCED (rows cut, but allowed to absorb freed land, so final area exceeds the old targets): dark_forest,
old_growth_birch_forest, flower_forest, dappled_forest, jungle, sparse_jungle, bamboo_jungle, badlands, wooded_badlands,
mangrove_swamp, swamp, taiga, snowy_taiga.

Sizes are simulation estimates, not measured in game. Declared pack format range 113-125.
